const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const path = require('path');
const { ChannelType, PermissionsBitField } = require('discord.js');
const { getConfig, saveConfig } = require('../config');
const { sendBanLog } = require('../banlog');

const API = 'https://discord.com/api/v10';

module.exports = function startWeb(client) {
  const { BASE_URL, CLIENT_ID, CLIENT_SECRET, SESSION_SECRET, PORT = 3000 } = process.env;
  const https = BASE_URL.startsWith('https');
  const redirectUri = `${BASE_URL.replace(/\/$/, '')}/auth/callback`;
  const inviteUrl =
    `https://discord.com/oauth2/authorize?client_id=${CLIENT_ID}&scope=bot%20applications.commands&permissions=` +
    new PermissionsBitField([
      'ViewChannel',
      'SendMessages',
      'EmbedLinks',
      'AttachFiles',
      'BanMembers',
      'ViewAuditLog',
    ]).bitfield;

  const app = express();
  if (https) app.set('trust proxy', 1);
  app.use(express.json({ limit: '100kb' }));
  app.use(
    session({
      name: 'sid',
      secret: SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'lax', secure: https, maxAge: 7 * 86_400_000 },
    })
  );
  app.use(express.static(path.join(__dirname, 'public')));

  const wrap = (fn) => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch((e) => {
      console.error(e);
      res.status(500).json({ error: 'Erro interno. Tente de novo.' });
    });

  const manageable = (g) => g.owner || (BigInt(g.permissions) & (0x8n | 0x20n)) !== 0n;

  // ---------- Login com Discord ----------
  app.get('/auth/login', (req, res) => {
    const state = crypto.randomBytes(16).toString('hex');
    req.session.state = state;
    const q = new URLSearchParams({
      client_id: CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'identify guilds',
      state,
    });
    res.redirect(`https://discord.com/oauth2/authorize?${q}`);
  });

  app.get('/auth/callback', async (req, res) => {
    const { code, state } = req.query;
    if (!code || !state || state !== req.session.state)
      return res.status(400).send('Sessão de login inválida. Volte e tente entrar novamente.');
    try {
      const tr = await fetch(`${API}/oauth2/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          grant_type: 'authorization_code',
          code: String(code),
          redirect_uri: redirectUri,
        }),
      });
      const tok = await tr.json();
      if (!tok.access_token) throw new Error('sem token');
      const headers = { Authorization: `Bearer ${tok.access_token}` };
      const [user, guilds] = await Promise.all([
        fetch(`${API}/users/@me`, { headers }).then((r) => r.json()),
        fetch(`${API}/users/@me/guilds`, { headers }).then((r) => r.json()),
      ]);
      delete req.session.state;
      req.session.user = { id: user.id, username: user.global_name || user.username, avatar: user.avatar };
      req.session.guilds = guilds.map((g) => ({
        id: g.id,
        name: g.name,
        icon: g.icon,
        owner: g.owner,
        permissions: g.permissions,
      }));
      res.redirect('/');
    } catch (e) {
      console.error('Falha no login OAuth:', e.message);
      res.status(500).send('Não foi possível entrar com o Discord. Confira CLIENT_SECRET e a URL de redirecionamento.');
    }
  });

  app.get('/auth/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

  // ---------- API ----------
  const auth = (req, res, next) =>
    req.session.user ? next() : res.status(401).json({ error: 'Faça login para continuar.' });

  const guildAccess = (req, res, next) => {
    const g = (req.session.guilds || []).find((x) => x.id === req.params.id);
    const guild = client.guilds.cache.get(req.params.id);
    if (!g || !manageable(g) || !guild)
      return res.status(403).json({ error: 'Você não tem acesso a este servidor.' });
    req.guild = guild;
    next();
  };

  app.get('/api/me', auth, (req, res) => {
    res.json({
      user: req.session.user,
      inviteUrl,
      guilds: (req.session.guilds || [])
        .filter((g) => manageable(g) && client.guilds.cache.has(g.id))
        .map((g) => ({ id: g.id, name: g.name })),
    });
  });

  app.get('/api/guilds/:id', auth, guildAccess, wrap(async (req, res) => {
    const all = await req.guild.channels.fetch();
    const channels = [...all.values()]
      .filter((c) => c && [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(c.type))
      .sort((a, b) => a.rawPosition - b.rawPosition)
      .map((c) => ({
        id: c.id,
        name: c.name,
        type: c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement ? 'text' : 'voice',
      }));
    const roles = [...req.guild.roles.cache.values()]
      .filter((r) => !r.managed && r.id !== req.guild.id)
      .sort((a, b) => b.position - a.position)
      .map((r) => ({ id: r.id, name: r.name }));
    res.json({ config: await getConfig(req.guild.id), channels, roles });
  }));

  app.put('/api/guilds/:id', auth, guildAccess, wrap(async (req, res) => {
    res.json({ config: await saveConfig(req.guild.id, req.body || {}) });
  }));

  app.post('/api/guilds/:id/test-log', auth, guildAccess, wrap(async (req, res) => {
    const target = await client.users.fetch(req.session.user.id).catch(() => null);
    if (!target) return res.status(400).json({ error: 'Não consegui carregar seu usuário.' });
    const r = await sendBanLog(req.guild, {
      target,
      moderator: client.user,
      reason: 'Teste de configuração do painel',
    });
    r.ok ? res.json({ ok: true }) : res.status(400).json({ error: r.error });
  }));

  app.listen(PORT, () => console.log(`Painel em ${BASE_URL} (porta ${PORT})`));
};
