require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, Collection, Events, GatewayIntentBits } = require('discord.js');
const { handleMessage, startVoiceTracker, flush } = require('./xp');
const { onGuildBanAdd } = require('./banlog');
const startWeb = require('./web/server');

for (const k of ['DISCORD_TOKEN', 'CLIENT_ID', 'CLIENT_SECRET', 'SESSION_SECRET', 'BASE_URL', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY']) {
  if (!process.env[k]) {
    console.error(`Falta a variável ${k} no arquivo .env`);
    process.exit(1);
  }
}

// Nenhuma intent privilegiada é necessária.
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration,
  ],
});

client.commands = new Collection();
for (const file of fs.readdirSync(path.join(__dirname, 'commands')).filter((f) => f.endsWith('.js'))) {
  const cmd = require(path.join(__dirname, 'commands', file));
  client.commands.set(cmd.data.name, cmd);
}

client.once(Events.ClientReady, async (c) => {
  console.log(`Bot online como ${c.user.tag}`);
  await c.application.commands.set([...client.commands.values()].map((x) => x.data.toJSON()));
  startVoiceTracker(client);
  startWeb(client);
});

client.on(Events.MessageCreate, handleMessage);
client.on(Events.GuildBanAdd, (ban) => onGuildBanAdd(ban).catch(console.error));

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const cmd = client.commands.get(interaction.commandName);
  if (!cmd) return;
  try {
    await cmd.execute(interaction);
  } catch (err) {
    console.error(err);
    const payload = { content: '❌ Algo deu errado ao executar o comando.', flags: 64 };
    if (interaction.deferred || interaction.replied) interaction.followUp(payload).catch(() => {});
    else interaction.reply(payload).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);

// Ao desligar, grava o XP que ainda estava na fila.
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, async () => {
    await flush().catch(() => {});
    process.exit(0);
  });
}
