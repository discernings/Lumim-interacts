const supabase = require('./db');
const { getConfig } = require('./config');

// XP necessário para sair do nível `l` para o `l + 1`.
const xpNeeded = (l) => 5 * l * l + 50 * l + 100;

function levelFromXp(xp) {
  let level = 0;
  let rest = xp;
  while (rest >= xpNeeded(level)) {
    rest -= xpNeeded(level);
    level++;
  }
  return { level, current: rest, needed: xpNeeded(level) };
}

// ---------- Fila de gravação ----------
// Em vez de gravar a cada mensagem, juntamos tudo na memória e enviamos ao Supabase
// em lote a cada poucos segundos (uma única chamada para todos os usuários).
const pending = new Map();

function queue(guildId, userId, { xp = 0, messages = 0, voice = 0, at = 0 }) {
  const k = `${guildId}:${userId}`;
  const p = pending.get(k) || {
    guild_id: guildId,
    user_id: userId,
    xp: 0,
    messages: 0,
    voice_seconds: 0,
    last_msg_at: 0,
  };
  p.xp += xp;
  p.messages += messages;
  p.voice_seconds += voice;
  if (at > p.last_msg_at) p.last_msg_at = at;
  pending.set(k, p);
}

let flushing = null;
function flush() {
  if (flushing) return flushing;
  flushing = (async () => {
    if (!pending.size) return;
    const rows = [...pending.values()];
    pending.clear();
    for (let i = 0; i < rows.length; i += 500) {
      const { error } = await supabase.rpc('add_stats_batch', { p_rows: rows.slice(i, i + 500) });
      if (error) {
        console.error('Falha ao salvar XP (vai tentar de novo):', error.message);
        for (const r of rows.slice(i)) {
          queue(r.guild_id, r.user_id, {
            xp: r.xp,
            messages: r.messages,
            voice: r.voice_seconds,
            at: r.last_msg_at,
          });
        }
        return;
      }
    }
  })().finally(() => {
    flushing = null;
  });
  return flushing;
}

// ---------- Leitura ----------
async function getUser(guildId, userId) {
  await flush(); // garante que o card mostre o XP mais recente
  const { data, error } = await supabase
    .from('users')
    .select('xp, messages, voice_seconds')
    .eq('guild_id', guildId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data
    ? { xp: Number(data.xp), messages: data.messages, voice_seconds: Number(data.voice_seconds) }
    : { xp: 0, messages: 0, voice_seconds: 0 };
}

async function getRank(guildId, userId) {
  const { data, error } = await supabase.rpc('get_rank', { p_guild: guildId, p_user: userId });
  if (error) throw error;
  return Number(data);
}

// ---------- XP por mensagem ----------
const cooldowns = new Map(); // "guild:user" -> timestamp do último XP

async function handleMessage(message) {
  try {
    if (!message.guild || message.author.bot || message.webhookId) return;
    const cfg = await getConfig(message.guild.id);
    if (!cfg.xpEnabled) return;
    const parent = message.channel.parentId;
    if (
      cfg.ignoredChannels.includes(message.channel.id) ||
      (parent && cfg.ignoredChannels.includes(parent))
    )
      return;

    const key = `${message.guild.id}:${message.author.id}`;
    const now = Date.now();
    if (now - (cooldowns.get(key) || 0) < cfg.msgCooldown * 1000) {
      queue(message.guild.id, message.author.id, { messages: 1 }); // conta a mensagem, sem XP
      return;
    }
    cooldowns.set(key, now);
    const xp = Math.floor(Math.random() * (cfg.msgXpMax - cfg.msgXpMin + 1)) + cfg.msgXpMin;
    queue(message.guild.id, message.author.id, { xp, messages: 1, at: now });
  } catch (e) {
    console.error('Erro no XP por mensagem:', e.message);
  }
}

// ---------- XP por tempo em call ----------
// A cada minuto: soma 60s de call para todo mundo em canal de voz (exceto AFK)
// e dá XP a quem estiver "elegível" (conforme as regras do painel).
function startVoiceTracker(client) {
  setInterval(async () => {
    for (const guild of client.guilds.cache.values()) {
      try {
        const cfg = await getConfig(guild.id);
        if (!cfg.xpEnabled) continue;
        for (const channel of guild.channels.cache.values()) {
          if (!channel.isVoiceBased() || channel.id === guild.afkChannelId) continue;
          if (cfg.ignoredChannels.includes(channel.id)) continue;
          const humans = [...channel.members.values()].filter((m) => !m.user.bot);
          const alone = humans.length < 2;
          for (const m of humans) {
            const v = m.voice;
            const muted = v.selfMute || v.serverMute || v.selfDeaf || v.serverDeaf;
            const eligible = !(cfg.voiceIgnoreAlone && alone) && !(cfg.voiceIgnoreMuted && muted);
            queue(guild.id, m.id, { voice: 60, xp: eligible ? cfg.voiceXpPerMinute : 0 });
          }
        }
      } catch (e) {
        console.error('Erro no XP de call:', e.message);
      }
    }
  }, 60_000);

  // Envia a fila ao banco a cada 15s e limpa cooldowns antigos.
  setInterval(() => {
    flush().catch((e) => console.error(e.message));
    const limit = Date.now() - 3_600_000;
    for (const [k, t] of cooldowns) if (t < limit) cooldowns.delete(k);
  }, 15_000);
}

// ---------- Perfil (descrição e fundo do card) ----------
async function getProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('description, bg_file')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data || { description: '', bg_file: null };
}

async function setDescription(userId, description) {
  const { error } = await supabase
    .from('profiles')
    .upsert({ user_id: userId, description }, { onConflict: 'user_id' });
  if (error) throw error;
}

async function setBgFile(userId, file) {
  const { error } = await supabase
    .from('profiles')
    .upsert({ user_id: userId, bg_file: file }, { onConflict: 'user_id' });
  if (error) throw error;
}

module.exports = {
  xpNeeded,
  levelFromXp,
  getUser,
  getRank,
  handleMessage,
  startVoiceTracker,
  flush,
  getProfile,
  setDescription,
  setBgFile,
};
