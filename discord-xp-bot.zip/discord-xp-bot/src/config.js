const supabase = require('./db');

const DEFAULTS = {
  // XP
  xpEnabled: true,
  msgXpMin: 15,
  msgXpMax: 25,
  msgCooldown: 60,
  voiceXpPerMinute: 10,
  voiceIgnoreMuted: true,
  voiceIgnoreAlone: true,
  ignoredChannels: [],
  // Permissões de ban
  banRoleIds: [],
  banUserIds: [],
  banDeleteDays: 0,
  // Log de ban
  log: {
    enabled: true,
    channelId: '',
    title: '🔨 Membro banido',
    description: '**{userTag}** foi banido por {moderator}.\n\n**Motivo:** {reason}',
    color: '#ed4245',
    footer: 'ID: {userId}',
    showThumbnail: true,
    showTimestamp: true,
    imageUrl: '',
    dmUser: false,
    dmMessage: 'Você foi banido de **{guild}**.\nMotivo: {reason}',
  },
};

const HEX = /^#[0-9a-fA-F]{6}$/;
const ID = /^\d{15,25}$/;
const str = (v, max, def) => (typeof v === 'string' ? v.slice(0, max) : def);
const bool = (v, def) => (typeof v === 'boolean' ? v : def);
const num = (v, min, max, def) => {
  v = Number(v);
  return Number.isFinite(v) ? Math.min(max, Math.max(min, Math.round(v))) : def;
};
const ids = (v, def) =>
  Array.isArray(v) ? [...new Set(v.map(String).filter((x) => ID.test(x)))].slice(0, 200) : def;

function sanitize(i = {}, b = DEFAULTS) {
  const l = i.log && typeof i.log === 'object' ? i.log : {};
  const bl = b.log;
  const cfg = {
    xpEnabled: bool(i.xpEnabled, b.xpEnabled),
    msgXpMin: num(i.msgXpMin, 0, 1000, b.msgXpMin),
    msgXpMax: num(i.msgXpMax, 0, 1000, b.msgXpMax),
    msgCooldown: num(i.msgCooldown, 0, 3600, b.msgCooldown),
    voiceXpPerMinute: num(i.voiceXpPerMinute, 0, 1000, b.voiceXpPerMinute),
    voiceIgnoreMuted: bool(i.voiceIgnoreMuted, b.voiceIgnoreMuted),
    voiceIgnoreAlone: bool(i.voiceIgnoreAlone, b.voiceIgnoreAlone),
    ignoredChannels: ids(i.ignoredChannels, b.ignoredChannels),
    banRoleIds: ids(i.banRoleIds, b.banRoleIds),
    banUserIds: ids(i.banUserIds, b.banUserIds),
    banDeleteDays: num(i.banDeleteDays, 0, 7, b.banDeleteDays),
    log: {
      enabled: bool(l.enabled, bl.enabled),
      channelId:
        typeof l.channelId === 'string' && (l.channelId === '' || ID.test(l.channelId))
          ? l.channelId
          : bl.channelId,
      title: str(l.title, 256, bl.title),
      description: str(l.description, 4000, bl.description),
      color: HEX.test(l.color) ? l.color : bl.color,
      footer: str(l.footer, 2000, bl.footer),
      showThumbnail: bool(l.showThumbnail, bl.showThumbnail),
      showTimestamp: bool(l.showTimestamp, bl.showTimestamp),
      imageUrl:
        typeof l.imageUrl === 'string' && (l.imageUrl === '' || /^https?:\/\//i.test(l.imageUrl))
          ? l.imageUrl.slice(0, 500)
          : bl.imageUrl,
      dmUser: bool(l.dmUser, bl.dmUser),
      dmMessage: str(l.dmMessage, 1500, bl.dmMessage),
    },
  };
  if (cfg.msgXpMin > cfg.msgXpMax) cfg.msgXpMax = cfg.msgXpMin;
  return cfg;
}

// Cache em memória: a config é lida a cada mensagem, então evitamos ir ao banco toda vez.
const cache = new Map();

async function getConfig(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const { data, error } = await supabase
    .from('guild_config')
    .select('data')
    .eq('guild_id', guildId)
    .maybeSingle();
  if (error) throw error;
  const cfg = data ? sanitize(data.data, DEFAULTS) : structuredClone(DEFAULTS);
  cache.set(guildId, cfg);
  return cfg;
}

async function saveConfig(guildId, input) {
  const next = sanitize(input, await getConfig(guildId));
  const { error } = await supabase
    .from('guild_config')
    .upsert({ guild_id: guildId, data: next, updated_at: new Date().toISOString() }, { onConflict: 'guild_id' });
  if (error) throw error;
  cache.set(guildId, next);
  return next;
}

module.exports = { DEFAULTS, getConfig, saveConfig };
