const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const fs = require('fs');
const path = require('path');
const supabase = require('./db');

const W = 900;
const H = 300;
const FONT_DIR = path.join(__dirname, '..', 'assets', 'fonts');

// Coloque Inter-Regular.ttf e Inter-Bold.ttf em assets/fonts para um visual mais limpo.
let FONT = 'sans-serif';
try {
  const reg = path.join(FONT_DIR, 'Inter-Regular.ttf');
  const bold = path.join(FONT_DIR, 'Inter-Bold.ttf');
  if (fs.existsSync(reg)) {
    GlobalFonts.registerFromPath(reg, 'Inter');
    if (fs.existsSync(bold)) GlobalFonts.registerFromPath(bold, 'Inter');
    FONT = 'Inter';
  }
} catch {}

const COLORS = { text: '#f3f4f7', muted: '#8d93a3', soft: '#c7cad2', accentA: '#8c9bff', accentB: '#6a79f5' };

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function wrap(ctx, text, maxW, maxLines) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (let i = 0; i < words.length; i++) {
    const test = line ? `${line} ${words[i]}` : words[i];
    if (ctx.measureText(test).width <= maxW) {
      line = test;
    } else {
      lines.push(line);
      line = words[i];
      if (lines.length === maxLines) break;
    }
  }
  if (lines.length < maxLines && line) lines.push(line);
  if (lines.length === maxLines && (words.join(' ') !== lines.join(' '))) {
    let last = lines[maxLines - 1];
    while (last.length > 1 && ctx.measureText(`${last}…`).width > maxW) last = last.slice(0, -1);
    lines[maxLines - 1] = `${last.replace(/[\s.,;:!?-]+$/, '')}…`;
  }
  return lines;
}

const compact = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1).replace(/\.0$/, '')}k` : String(n));
function fmtVoice(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

async function fetchAvatar(user) {
  const url = user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
  const res = await fetch(url);
  return loadImage(Buffer.from(await res.arrayBuffer()));
}

async function generateCard({ user, displayName, description, bgFile, xp, level, current, needed, rank, messages, voiceSeconds }) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // Fundo
  ctx.save();
  rr(ctx, 0, 0, W, H, 28);
  ctx.clip();
  let hasBg = false;
  if (bgFile) {
    try {
      const buf = await getBackground(bgFile);
      if (buf) {
        ctx.drawImage(await loadImage(buf), 0, 0, W, H);
        hasBg = true;
      }
    } catch {}
  }
  if (!hasBg) {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#181b24');
    g.addColorStop(1, '#0d0f14');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  } else {
    ctx.fillStyle = 'rgba(8, 9, 12, 0.62)'; // garante legibilidade sobre qualquer imagem
    ctx.fillRect(0, 0, W, H);
  }
  ctx.restore();

  // Borda fina
  rr(ctx, 0.5, 0.5, W - 1, H - 1, 28);
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Avatar
  const cx = 96, cy = 96, r = 52;
  try {
    const avatar = await fetchAvatar(user);
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(avatar, cx - r, cy - r, r * 2, r * 2);
    ctx.restore();
  } catch {}
  ctx.beginPath();
  ctx.arc(cx, cy, r + 2, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Nome e usuário
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.fillStyle = COLORS.text;
  ctx.font = `700 30px ${FONT}`;
  let name = displayName;
  while (name.length > 1 && ctx.measureText(name).width > 470) name = name.slice(0, -1);
  if (name !== displayName) name += '…';
  ctx.fillText(name, 176, 88);
  ctx.fillStyle = COLORS.muted;
  ctx.font = `400 15px ${FONT}`;
  ctx.fillText(`@${user.username}`, 176, 112);

  // Descrição
  ctx.font = `400 15px ${FONT}`;
  if (description) {
    ctx.fillStyle = COLORS.soft;
    wrap(ctx, description, 470, 2).forEach((l, i) => ctx.fillText(l, 176, 148 + i * 22));
  } else {
    ctx.fillStyle = '#666c7c';
    ctx.fillText('Sem descrição ainda. Use /descricao para criar a sua.', 176, 148);
  }

  // Estatísticas
  const stats = [
    ['Mensagens', compact(messages)],
    ['Tempo em call', fmtVoice(voiceSeconds)],
    ['XP total', compact(xp)],
  ];
  stats.forEach(([label, value], i) => {
    const x = 176 + i * 140;
    ctx.fillStyle = COLORS.muted;
    ctx.font = `400 12px ${FONT}`;
    ctx.fillText(label, x, 204);
    ctx.fillStyle = COLORS.text;
    ctx.font = `700 17px ${FONT}`;
    ctx.fillText(value, x, 226);
  });

  // Nível e rank (direita)
  ctx.textAlign = 'right';
  ctx.fillStyle = COLORS.muted;
  ctx.font = `400 13px ${FONT}`;
  ctx.fillText('Nível', W - 44, 62);
  ctx.fillStyle = COLORS.text;
  ctx.font = `700 56px ${FONT}`;
  ctx.fillText(String(level), W - 44, 114);
  ctx.fillStyle = COLORS.muted;
  ctx.font = `400 13px ${FONT}`;
  ctx.fillText('Posição no servidor', W - 44, 152);
  ctx.fillStyle = COLORS.text;
  ctx.font = `700 24px ${FONT}`;
  ctx.fillText(`#${rank}`, W - 44, 180);

  // Barra de progresso
  ctx.font = `400 12px ${FONT}`;
  ctx.fillStyle = COLORS.muted;
  ctx.textAlign = 'left';
  ctx.fillText(`Nível ${level} → ${level + 1}`, 44, 252);
  ctx.textAlign = 'right';
  ctx.fillText(`${current.toLocaleString('pt-BR')} / ${needed.toLocaleString('pt-BR')} XP`, W - 44, 252);

  const bx = 44, by = 262, bw = W - 88, bh = 10;
  rr(ctx, bx, by, bw, bh, 5);
  ctx.fillStyle = 'rgba(255,255,255,0.10)';
  ctx.fill();
  const fillW = Math.max(bh, Math.round(bw * Math.min(1, current / needed)));
  const grad = ctx.createLinearGradient(bx, 0, bx + bw, 0);
  grad.addColorStop(0, COLORS.accentA);
  grad.addColorStop(1, COLORS.accentB);
  rr(ctx, bx, by, fillW, bh, 5);
  ctx.fillStyle = grad;
  ctx.fill();

  return canvas.encode('png');
}

// ---------- Fundos (Supabase Storage, bucket "backgrounds") ----------
const BUCKET = 'backgrounds';
const bgCache = new Map(); // arquivo -> Buffer (evita baixar a cada /perfil)

async function getBackground(file) {
  if (bgCache.has(file)) return bgCache.get(file);
  const { data, error } = await supabase.storage.from(BUCKET).download(file);
  if (error || !data) return null;
  const buf = Buffer.from(await data.arrayBuffer());
  if (bgCache.size >= 50) bgCache.delete(bgCache.keys().next().value);
  bgCache.set(file, buf);
  return buf;
}

// Normaliza o fundo enviado (900x300, "cover") e envia ao Storage.
async function saveBackground(userId, buffer) {
  const img = await loadImage(buffer);
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  const scale = Math.max(W / img.width, H / img.height);
  const dw = img.width * scale;
  const dh = img.height * scale;
  ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
  const png = await canvas.encode('png');
  const file = `${userId}.png`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(file, png, { contentType: 'image/png', upsert: true });
  if (error) throw error;
  bgCache.set(file, png);
  return file;
}

async function removeBackground(file) {
  if (!file) return;
  bgCache.delete(file);
  await supabase.storage.from(BUCKET).remove([file]);
}

module.exports = { generateCard, saveBackground, removeBackground };
