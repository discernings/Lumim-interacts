const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { getConfig } = require('./config');

const render = (tpl, vars) =>
  String(tpl || '').replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));

function buildVars(guild, { target, moderator, reason }) {
  return {
    user: `<@${target.id}>`,
    userTag: target.username,
    userId: target.id,
    moderator: moderator ? `<@${moderator.id}>` : 'Desconhecido',
    moderatorTag: moderator ? moderator.username : 'Desconhecido',
    moderatorId: moderator ? moderator.id : '0',
    reason: reason || 'Não informado',
    guild: guild.name,
    date: `<t:${Math.floor(Date.now() / 1000)}:F>`,
    memberCount: String(guild.memberCount),
  };
}

function buildEmbed(cfg, vars, target) {
  const l = cfg.log;
  const embed = new EmbedBuilder().setColor(parseInt(l.color.slice(1), 16));
  const title = render(l.title, vars).slice(0, 256);
  let desc = render(l.description, vars).slice(0, 4000);
  if (title) embed.setTitle(title);
  if (desc) embed.setDescription(desc);
  if (!title && !desc) embed.setDescription(`${vars.userTag} foi banido.`);
  const footer = render(l.footer, vars).slice(0, 2000);
  if (footer) embed.setFooter({ text: footer });
  if (l.showThumbnail) embed.setThumbnail(target.displayAvatarURL({ size: 256 }));
  if (l.showTimestamp) embed.setTimestamp();
  if (l.imageUrl) embed.setImage(l.imageUrl);
  return embed;
}

async function sendBanLog(guild, data) {
  const cfg = await getConfig(guild.id);
  if (!cfg.log.enabled) return { ok: false, error: 'Os logs de ban estão desativados.' };
  if (!cfg.log.channelId) return { ok: false, error: 'Nenhum canal de logs foi escolhido.' };
  const channel = await guild.channels.fetch(cfg.log.channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return { ok: false, error: 'Canal de logs não encontrado.' };
  try {
    const vars = buildVars(guild, data);
    await channel.send({ embeds: [buildEmbed(cfg, vars, data.target)] });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: 'O bot não consegue enviar mensagens nesse canal.' };
  }
}

async function sendBanDm(guild, target, reason) {
  const cfg = await getConfig(guild.id);
  if (!cfg.log.dmUser) return;
  const vars = buildVars(guild, { target, moderator: null, reason });
  await target.send(render(cfg.log.dmMessage, vars).slice(0, 2000)).catch(() => {});
}

// Evita log duplicado: o /ban já loga sozinho, então marcamos para o evento ignorar.
const handled = new Set();
function markHandled(guildId, userId) {
  const k = `${guildId}:${userId}`;
  handled.add(k);
  setTimeout(() => handled.delete(k), 30_000);
}

// Bans feitos manualmente (menu do Discord, outros bots) também geram log.
async function onGuildBanAdd(ban) {
  await new Promise((r) => setTimeout(r, 1500));
  if (handled.has(`${ban.guild.id}:${ban.user.id}`)) return;
  if (ban.partial) ban = await ban.fetch().catch(() => ban);
  let moderator = null;
  let reason = ban.reason;
  try {
    const logs = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 5 });
    const entry = logs.entries.find(
      (e) => e.target?.id === ban.user.id && Date.now() - e.createdTimestamp < 15_000
    );
    if (entry) {
      if (entry.executor?.id === ban.client.user.id) return;
      moderator = entry.executor;
      reason = entry.reason || reason;
    }
  } catch {}
  await sendBanLog(ban.guild, { target: ban.user, moderator, reason });
}

module.exports = { sendBanLog, sendBanDm, markHandled, onGuildBanAdd };
