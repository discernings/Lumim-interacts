const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');

const ts = (ms) => Math.floor(ms / 1000);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Mostra informações de um usuário')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('Quem consultar (padrão: você)')),
  async execute(interaction) {
    await interaction.deferReply();
    const base = interaction.options.getUser('usuario') || interaction.user;
    const user = await base.fetch(true); // traz banner e cor de destaque
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    const years = ((Date.now() - user.createdTimestamp) / (365.25 * 86_400_000)).toFixed(1);
    const avatar = user.displayAvatarURL({ size: 4096 });

    const embed = new EmbedBuilder()
      .setColor(user.accentColor || member?.displayColor || 0x7c8cff)
      .setAuthor({ name: user.globalName || user.username, iconURL: user.displayAvatarURL({ size: 64 }) })
      .setThumbnail(user.displayAvatarURL({ size: 512 }))
      .addFields(
        { name: 'Usuário', value: `${user} (@${user.username})`, inline: true },
        { name: 'ID', value: `\`${user.id}\``, inline: true },
        { name: 'Tipo', value: user.bot ? 'Bot' : 'Pessoa', inline: true },
        {
          name: 'Conta criada',
          value: `<t:${ts(user.createdTimestamp)}:F>\n<t:${ts(user.createdTimestamp)}:R> (${years} anos)`,
          inline: false,
        }
      );

    if (member) {
      if (member.nickname) embed.addFields({ name: 'Apelido', value: member.nickname, inline: true });
      embed.addFields({
        name: 'Entrou no servidor',
        value: `<t:${ts(member.joinedTimestamp)}:F>\n<t:${ts(member.joinedTimestamp)}:R>`,
        inline: true,
      });
      if (member.premiumSinceTimestamp)
        embed.addFields({
          name: 'Impulsionando desde',
          value: `<t:${ts(member.premiumSinceTimestamp)}:D>`,
          inline: true,
        });
      const roles = member.roles.cache
        .filter((r) => r.id !== interaction.guild.id)
        .sort((a, b) => b.position - a.position);
      if (roles.size)
        embed.addFields({
          name: `Cargos (${roles.size})`,
          value: roles.first(15).map((r) => r.toString()).join(' ') + (roles.size > 15 ? ' …' : ''),
        });
    } else {
      embed.setFooter({ text: 'Este usuário não está no servidor.' });
    }

    const banner = user.bannerURL({ size: 1024 });
    if (banner) embed.setImage(banner);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('Abrir avatar').setURL(avatar)
    );
    await interaction.editReply({ embeds: [embed], components: [row] });
  },
};
