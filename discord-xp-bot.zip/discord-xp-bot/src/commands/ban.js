const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getConfig } = require('../config');
const { sendBanLog, sendBanDm, markHandled } = require('../banlog');

const deny = (i, msg) => i.reply({ content: `❌ ${msg}`, flags: 64 });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bane um usuário do servidor')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('Quem banir').setRequired(true))
    .addStringOption((o) => o.setName('motivo').setDescription('Motivo do banimento').setMaxLength(400))
    .addIntegerOption((o) =>
      o
        .setName('apagar_mensagens')
        .setDescription('Dias de mensagens para apagar (0 a 7)')
        .setMinValue(0)
        .setMaxValue(7)
    ),
  async execute(interaction) {
    const { guild, member: mod, client } = interaction;
    const cfg = await getConfig(guild.id);

    // Quem pode usar: dono, administradores, usuários e cargos liberados no painel.
    const allowed =
      guild.ownerId === mod.id ||
      mod.permissions.has(PermissionFlagsBits.Administrator) ||
      cfg.banUserIds.includes(mod.id) ||
      mod.roles.cache.some((r) => cfg.banRoleIds.includes(r.id));
    if (!allowed) return deny(interaction, 'Você não tem permissão para usar este comando.');

    if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers))
      return deny(interaction, 'Eu preciso da permissão "Banir Membros" neste servidor.');

    const target = interaction.options.getUser('usuario');
    const reason = interaction.options.getString('motivo') || 'Não informado';
    const days = interaction.options.getInteger('apagar_mensagens') ?? cfg.banDeleteDays;

    if (target.id === mod.id) return deny(interaction, 'Você não pode banir a si mesmo.');
    if (target.id === client.user.id) return deny(interaction, 'Eu não posso me banir.');
    if (target.id === guild.ownerId) return deny(interaction, 'Não dá para banir o dono do servidor.');

    const tm = await guild.members.fetch(target.id).catch(() => null);
    if (tm) {
      if (guild.ownerId !== mod.id && mod.roles.highest.comparePositionTo(tm.roles.highest) <= 0)
        return deny(interaction, 'Esse usuário tem um cargo igual ou acima do seu.');
      if (!tm.bannable)
        return deny(interaction, 'Não consigo banir esse usuário: o cargo dele está acima do meu.');
    }

    await interaction.deferReply({ flags: 64 });
    await sendBanDm(guild, target, reason);
    markHandled(guild.id, target.id);
    try {
      await guild.members.ban(target.id, {
        reason: `[${mod.user.username}] ${reason}`,
        deleteMessageSeconds: days * 86400,
      });
    } catch (e) {
      return interaction.editReply('❌ Não consegui banir esse usuário.');
    }
    const log = await sendBanLog(guild, { target, moderator: mod.user, reason });
    await interaction.editReply(
      `✅ **${target.username}** foi banido.` + (log.ok ? '' : `\n⚠️ Log não enviado: ${log.error}`)
    );
  },
};
