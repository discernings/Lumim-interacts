const { SlashCommandBuilder } = require('discord.js');
const { setDescription } = require('../xp');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('descricao')
    .setDescription('Define a descrição que aparece no seu card de perfil')
    .addStringOption((o) =>
      o.setName('texto').setDescription('Sua descrição (deixe vazio para remover)').setMaxLength(140)
    ),
  async execute(interaction) {
    const text = (interaction.options.getString('texto') || '').replace(/\s+/g, ' ').trim();
    await setDescription(interaction.user.id, text);
    await interaction.reply({
      content: text ? 'Descrição atualizada. Veja o resultado com /perfil.' : 'Descrição removida.',
      flags: 64,
    });
  },
};
