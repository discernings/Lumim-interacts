const { SlashCommandBuilder } = require('discord.js');
const { getProfile, setBgFile } = require('../xp');
const { saveBackground, removeBackground } = require('../card');

const MAX_BYTES = 8 * 1024 * 1024;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fundo')
    .setDescription('Muda o fundo do seu card de perfil')
    .addSubcommand((s) =>
      s
        .setName('definir')
        .setDescription('Envia uma imagem para usar de fundo')
        .addAttachmentOption((o) =>
          o.setName('imagem').setDescription('PNG, JPG ou WEBP (até 8 MB)').setRequired(true)
        )
    )
    .addSubcommand((s) => s.setName('remover').setDescription('Volta ao fundo padrão')),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const profile = await getProfile(interaction.user.id);

    if (sub === 'remover') {
      await removeBackground(profile.bg_file);
      await setBgFile(interaction.user.id, null);
      return interaction.reply({ content: 'Fundo removido.', flags: 64 });
    }

    const att = interaction.options.getAttachment('imagem');
    if (!/^image\/(png|jpe?g|webp)/.test(att.contentType || ''))
      return interaction.reply({ content: 'Envie uma imagem PNG, JPG ou WEBP.', flags: 64 });
    if (att.size > MAX_BYTES)
      return interaction.reply({ content: 'A imagem passa de 8 MB. Envie uma menor.', flags: 64 });

    await interaction.deferReply({ flags: 64 });
    try {
      const res = await fetch(att.url);
      const file = await saveBackground(interaction.user.id, Buffer.from(await res.arrayBuffer()));
      await setBgFile(interaction.user.id, file);
      await interaction.editReply('Fundo atualizado. Veja o resultado com /perfil.');
    } catch {
      await interaction.editReply('Não consegui ler essa imagem. Tente outro arquivo.');
    }
  },
};
