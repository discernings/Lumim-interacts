const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getUser, getRank, getProfile, levelFromXp } = require('../xp');
const { generateCard } = require('../card');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('perfil')
    .setDescription('Mostra o card de perfil com seu XP')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('usuario').setDescription('De quem ver o perfil (padrão: você)')),
  async execute(interaction) {
    const user = interaction.options.getUser('usuario') || interaction.user;
    if (user.bot) return interaction.reply({ content: 'Bots não têm perfil de XP.', flags: 64 });
    await interaction.deferReply();

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    const row = await getUser(interaction.guildId, user.id);
    const profile = await getProfile(user.id);
    const lvl = levelFromXp(row.xp);

    const png = await generateCard({
      user,
      displayName: member?.displayName || user.globalName || user.username,
      description: profile.description,
      bgFile: profile.bg_file,
      xp: row.xp,
      ...lvl,
      rank: await getRank(interaction.guildId, user.id),
      messages: row.messages,
      voiceSeconds: row.voice_seconds,
    });
    await interaction.editReply({ files: [new AttachmentBuilder(png, { name: 'perfil.png' })] });
  },
};
