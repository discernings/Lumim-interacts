const { createClient } = require('@supabase/supabase-js');

// Chave service_role: só roda no servidor do bot. Nunca exponha no front-end.
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

module.exports = supabase;
