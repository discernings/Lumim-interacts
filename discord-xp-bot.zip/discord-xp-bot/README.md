# Bot de Discord: XP, painel web, logs de ban e card de perfil

## O que tem

| Recurso | Como funciona |
|---|---|
| XP por mensagem | XP aleatório (mín/máx) com intervalo entre ganhos, configurável no painel |
| XP por call | A cada minuto o bot soma tempo de call e XP (ignora canal AFK; opcionalmente ignora mutados e quem está sozinho) |
| Painel web | Login com Discord. Só quem tem **Gerenciar Servidor** ou **Administrador** configura aquele servidor |
| Quem pode banir | Cargos e usuários liberados pelo painel (dono e admins sempre podem) |
| Logs de ban | Canal, título, descrição, rodapé, cor, imagem, miniatura e aviso por DM, com pré-visualização e botão de teste |
| Card de perfil | `/perfil`, `/descricao`, `/fundo definir` e `/fundo remover` |
| Info de usuário | `/userinfo`: avatar, banner, conta criada (data e anos), entrada no servidor, cargos, boost |
| Ban | `/ban usuario motivo apagar_mensagens` |

Bans feitos manualmente pelo Discord também geram log (o bot lê o registro de auditoria para saber o moderador).

## Instalação

Requer Node.js 18.17 ou mais novo. Os dados ficam no **Supabase** (tabelas `guild_config`, `users`, `profiles` e o bucket privado `backgrounds`). O arquivo `supabase/schema.sql` documenta tudo, caso precise recriar em outro projeto.

1. No [Discord Developer Portal](https://discord.com/developers/applications), crie um aplicativo.
2. Em **Bot**, copie o token. Não precisa ligar nenhuma intent privilegiada.
3. Em **OAuth2**, copie o Client ID e o Client Secret e adicione o redirect `http://localhost:3000/auth/callback` (troque pela sua URL ao hospedar).
4. No Supabase, em **Project Settings → API Keys**, copie a chave **service_role** (secreta).
5. `cp .env.example .env` e preencha os valores (inclusive `SUPABASE_SERVICE_ROLE_KEY`).
6. `npm install`
7. `npm start`
8. Abra o painel, clique em **Adicionar o bot a outro servidor** para convidá-lo e depois recarregue.

O convite já pede as permissões: Ver canais, Enviar mensagens, Inserir links, Anexar arquivos, Banir membros e Ver registro de auditoria.

## Hospedagem

O GitHub Pages não roda este projeto (é um servidor Node). Suba o código no GitHub e conecte o repositório a um host que rode Node 24h (VPS ou plataforma como Railway, Fly.io ou Render). Cadastre as variáveis do `.env` na tela de variáveis de ambiente do host. Como os dados estão no Supabase, **não é preciso disco persistente**. Depois, defina `BASE_URL` com a URL pública e adicione `BASE_URL/auth/callback` nos Redirects do Discord.

## Dicas

- **Fonte do card:** crie `assets/fonts/` e coloque `Inter-Regular.ttf` e `Inter-Bold.ttf`. Sem elas o card usa a fonte padrão do sistema (em Linux, instale por exemplo `fonts-dejavu`).
- **Hierarquia:** para o `/ban` funcionar, o cargo do bot precisa estar acima do cargo do alvo.
- **Segurança:** `.env` e a chave `service_role` nunca vão para o GitHub. Se vazarem, gere novas.
- **Gravação de XP:** o XP é juntado na memória e enviado em lote a cada 15 segundos (e ao desligar o bot).
- **Fórmula de nível:** `5·n² + 50·n + 100` XP para ir do nível n ao n+1 (em `src/xp.js`, função `xpNeeded`).
