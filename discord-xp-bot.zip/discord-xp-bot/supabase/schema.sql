-- Já aplicado no projeto "Discord-bot-xp". Guardado aqui só como documentação / para recriar em outro projeto.

create table public.guild_config (
  guild_id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.users (
  guild_id text not null,
  user_id text not null,
  xp bigint not null default 0,
  messages integer not null default 0,
  voice_seconds bigint not null default 0,
  last_msg_at bigint not null default 0,
  primary key (guild_id, user_id)
);
create index idx_users_guild_xp on public.users (guild_id, xp desc);

create table public.profiles (
  user_id text primary key,
  description text not null default '',
  bg_file text
);

-- Só a chave service_role (usada pelo bot) acessa estas tabelas.
alter table public.guild_config enable row level security;
alter table public.users enable row level security;
alter table public.profiles enable row level security;

create or replace function public.add_stats_batch(p_rows jsonb)
returns void
language sql
set search_path = public
as $$
  insert into public.users as u (guild_id, user_id, xp, messages, voice_seconds, last_msg_at)
  select r.guild_id, r.user_id, r.xp, r.messages, r.voice_seconds, r.last_msg_at
  from jsonb_to_recordset(p_rows) as r(
    guild_id text, user_id text, xp bigint, messages integer, voice_seconds bigint, last_msg_at bigint
  )
  on conflict (guild_id, user_id) do update set
    xp = u.xp + excluded.xp,
    messages = u.messages + excluded.messages,
    voice_seconds = u.voice_seconds + excluded.voice_seconds,
    last_msg_at = case when excluded.last_msg_at > 0 then excluded.last_msg_at else u.last_msg_at end;
$$;

create or replace function public.get_rank(p_guild text, p_user text)
returns bigint
language sql
stable
set search_path = public
as $$
  select count(*) + 1 from public.users
  where guild_id = p_guild
    and xp > coalesce((select xp from public.users where guild_id = p_guild and user_id = p_user), 0);
$$;

revoke execute on function public.add_stats_batch(jsonb) from public, anon, authenticated;
revoke execute on function public.get_rank(text, text) from public, anon, authenticated;
grant execute on function public.add_stats_batch(jsonb) to service_role;
grant execute on function public.get_rank(text, text) to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('backgrounds', 'backgrounds', false, 5242880, array['image/png'])
on conflict (id) do nothing;
